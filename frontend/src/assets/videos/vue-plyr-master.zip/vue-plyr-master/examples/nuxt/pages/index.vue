<template>
	<demo />
</template>

<script>
	import Demo from '../../shared/demo'

	export default {
		components: {
			Demo
		}
	}
</script>
