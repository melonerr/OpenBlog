<template>
	<div>
		<h2>vimeo embed</h2>
		<vue-plyr>
			<div class="plyr__video-embed">
				<iframe
					src="https://player.vimeo.com/video/143418951?loop=false&amp;byline=false&amp;portrait=false&amp;title=false&amp;speed=true&amp;transparent=0&amp;gesture=media"
					allowfullscreen
					allowtransparency
					allow="autoplay"
				></iframe>
			</div>
		</vue-plyr>
	</div>
</template>
