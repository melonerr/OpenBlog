# vue-plyr-html
> An example of how to use vue-plyr with just html.

## Usage

``` bash
# install dependencies
$ yarn install

# run the server on port 5000
$ yarn start
```
