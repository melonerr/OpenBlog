<template>
	<demo />
</template>

<script>
	import Demo from './components/demo.vue'

	export default {
		name: 'App',
		components: {
			Demo
		}
	}
</script>
