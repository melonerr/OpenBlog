<template>
	<demo />
</template>

<script>
	import Demo from '../../shared/demo'

	export default {
		name: 'App',
		components: {
			Demo
		}
	}
</script>
