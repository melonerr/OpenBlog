<template>
	<div>
		<h2>youtube (not progressive-enhancement)</h2>
		<vue-plyr>
			<div data-plyr-provider="youtube" data-plyr-embed-id="bTqVqk7FSmY"></div>
		</vue-plyr>
	</div>
</template>
