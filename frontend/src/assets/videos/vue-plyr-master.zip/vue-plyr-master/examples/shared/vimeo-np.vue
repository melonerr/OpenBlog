<template>
	<div>
		<h2>vimeo (not progressive-enhancement)</h2>
		<vue-plyr>
			<div data-plyr-provider="vimeo" data-plyr-embed-id="143418951"></div>
		</vue-plyr>
	</div>
</template>
