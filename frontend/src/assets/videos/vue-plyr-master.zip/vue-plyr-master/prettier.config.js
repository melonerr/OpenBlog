module.exports = {
	useTabs: true,
	arrowParens: 'avoid',
	proseWrap: 'always',
	trailingComma: 'none',
	semi: false,
	singleQuote: true,
	vueIndentScriptAndStyle: true
}
